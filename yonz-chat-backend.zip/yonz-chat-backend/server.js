require("dotenv").config();

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const Pusher = require("pusher");

const required = ["PUSHER_APP_ID", "PUSHER_KEY", "PUSHER_SECRET", "PUSHER_CLUSTER"];
const missing = required.filter((key) => !process.env[key] || process.env[key].startsWith("ISI_"));
if (missing.length) {
  console.error("Environment variable belum diisi:", missing.join(", "));
  process.exit(1);
}

const app = express();
const PORT = Number(process.env.PORT || 3000);
const MAX_MESSAGE_LENGTH = Math.min(
  2000,
  Math.max(1, Number(process.env.MAX_MESSAGE_LENGTH || 1000))
);

const allowedOrigins = (process.env.ALLOWED_ORIGINS || "")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

const pusher = new Pusher({
  appId: process.env.PUSHER_APP_ID,
  key: process.env.PUSHER_KEY,
  secret: process.env.PUSHER_SECRET,
  cluster: process.env.PUSHER_CLUSTER,
  useTLS: true
});

app.disable("x-powered-by");
app.use(helmet());
app.use(express.json({ limit: "10kb" }));
app.use(cors({
  origin(origin, callback) {
    // Permintaan tanpa Origin (misalnya health check) diperbolehkan.
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error("Origin tidak diizinkan oleh ALLOWED_ORIGINS"));
  },
  methods: ["GET", "POST"],
  allowedHeaders: ["Content-Type"]
}));

const sendLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 12,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Terlalu banyak pesan. Coba lagi sebentar." }
});

const history = [];
const HISTORY_LIMIT = 100;

app.get("/", (_req, res) => {
  res.type("text").send("YONZ CHAT API is running");
});

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "yonz-chat-api" });
});

app.get("/api/messages", (_req, res) => {
  res.set("Cache-Control", "no-store");
  res.json({ messages: history });
});

app.post("/api/messages", sendLimiter, async (req, res) => {
  const name = typeof req.body?.name === "string" ? req.body.name.trim() : "";
  const text = typeof req.body?.text === "string" ? req.body.text.trim() : "";

  if (name.length < 2 || name.length > 24) {
    return res.status(400).json({ error: "Nama harus 2–24 karakter." });
  }
  if (!/^[\p{L}\p{N} _.-]+$/u.test(name)) {
    return res.status(400).json({ error: "Nama berisi karakter yang tidak diizinkan." });
  }
  if (!text || text.length > MAX_MESSAGE_LENGTH) {
    return res.status(400).json({
      error: `Pesan wajib diisi dan maksimal ${MAX_MESSAGE_LENGTH} karakter.`
    });
  }

  const message = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
    name,
    text,
    createdAt: new Date().toISOString()
  };

  try {
    // Pusher mengirim event ke semua client yang subscribe ke channel publik.
    await pusher.trigger("public-chat", "new-message", message);
    history.push(message);
    if (history.length > HISTORY_LIMIT) history.shift();
    return res.status(201).json({ ok: true, message });
  } catch (err) {
    console.error("Pusher trigger gagal:", err.message);
    return res.status(502).json({ error: "Pesan gagal dikirim. Coba lagi." });
  }
});

// Hindari menampilkan detail internal server ke pengunjung.
app.use((err, _req, res, _next) => {
  if (err.message?.includes("Origin tidak diizinkan")) {
    return res.status(403).json({ error: "Origin tidak diizinkan." });
  }
  if (err instanceof SyntaxError && "body" in err) {
    return res.status(400).json({ error: "Format JSON tidak valid." });
  }
  console.error(err);
  return res.status(500).json({ error: "Terjadi kesalahan server." });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`YONZ CHAT API berjalan pada port ${PORT}`);
});
