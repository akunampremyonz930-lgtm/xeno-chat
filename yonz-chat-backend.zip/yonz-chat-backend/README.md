# YONZ CHAT Backend (Pusher Channels)

Backend Node.js/Express untuk mengirim pesan ke satu channel publik Pusher bernama `public-chat`.

## Penting sebelum deploy

- Anda telah membagikan Pusher secret di chat. Rotasi/ganti secret di dashboard Pusher terlebih dahulu, lalu gunakan secret BARU di environment variables.
- Jangan masukkan `PUSHER_SECRET` ke HTML, JavaScript frontend, atau repository GitHub.
- GitHub Actions bukan hosting server realtime yang selalu hidup. Gunakan Render, Railway, atau server Node.js yang berjalan terus.
- Implementasi ini menyimpan 100 pesan terakhir di memori. Riwayat hilang saat server restart/sleep dan tidak tersinkron permanen. Untuk riwayat permanen, tambahkan database.
- Nama saat ini hanya validasi tampilan; tanpa sistem akun/autentikasi, pengunjung bisa berpura-pura memakai nama orang lain. Jangan gunakan untuk data sensitif.

## Jalankan lokal

1. Install Node.js 20+.
2. Salin `.env.example` menjadi `.env`.
3. Isi `PUSHER_APP_ID`, `PUSHER_KEY`, `PUSHER_SECRET` (secret baru), `PUSHER_CLUSTER`.
4. Isi `ALLOWED_ORIGINS` dengan origin frontend Anda. Saat uji lokal, misalnya `http://localhost:5500`.
5. Jalankan:

   ```bash
   npm install
   npm start
   ```

6. Tes `http://localhost:3000/health`. Hasil seharusnya `{"ok":true,"service":"yonz-chat-api"}`.

## Deploy ke Render

1. Upload isi folder ini ke repository GitHub.
2. Buka https://render.com/ dan buat **New Web Service**, hubungkan repository.
3. Runtime: Node. Build Command: `npm install`. Start Command: `npm start`.
4. Tambahkan environment variables di dashboard Render:
   - `PUSHER_APP_ID`
   - `PUSHER_KEY`
   - `PUSHER_SECRET` (secret BARU)
   - `PUSHER_CLUSTER`
   - `ALLOWED_ORIGINS` (URL frontend, tanpa slash di ujung; beberapa origin dipisah koma)
   - `MAX_MESSAGE_LENGTH=1000`
5. Deploy. Buka URL service `/health` untuk memastikan aktif.
6. Pada HTML frontend, set `API_BASE` ke URL Render dan `PUSHER_KEY` serta `PUSHER_CLUSTER` sesuai aplikasi Pusher.

Catatan: layanan gratis dapat sleep dan filesystem/memori tidak cocok untuk menyimpan data permanen. Pusher event juga tidak menyimpan riwayat chat.

## API

- `GET /health` — health check.
- `GET /api/messages` — mengambil hingga 100 pesan terakhir yang masih berada di memori.
- `POST /api/messages` — JSON `{ "name": "YONZ", "text": "Halo semua" }`.

Rate limit pengiriman: 12 request per menit per alamat IP (bergantung dukungan proxy hosting).
